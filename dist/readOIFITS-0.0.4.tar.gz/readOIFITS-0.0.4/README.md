# ReadOIFITS

Here soon a description of the project
